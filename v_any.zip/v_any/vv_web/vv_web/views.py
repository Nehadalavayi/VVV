
from _csv import writer

from django.http import HttpResponse
from wsgiref.util import FileWrapper


import os
from django.shortcuts import render
def home(request):
    return render(request, 'index.html')
def inx(request):
    return render(request,'index.html')
file_path = 'vv_web/file.csv'
def result(request):
    Teaching=request.GET['Teaching']
    course_content=request.GET['course_content']
    examination=request.GET['examination']
    lab_work=request.GET['lab_work']
    library=request.GET['library']
    extra=request.GET['extracurricular']

    with open(file_path, 'a+', newline='') as write_obj:
        # Create a writer object from csv module
        csv_writer = writer(write_obj)
        # Add contents of list as last row in the csv file
        csv_writer.writerow([Teaching,course_content,examination,lab_work,library,extra])

    return(render(request,'thanks.html'))
    # decide the file name
    # write the headers
def dd(request):
    wrapper = FileWrapper(open(file_path, 'rb'))
    response = HttpResponse(wrapper, content_type='text/csv')
    response['Content-Disposition'] = 'inline; filename=' + os.path.basename(file_path)
    return response

def hom(request):
    return render(request,'hom.html')


def any(request):
    filename = 'vv_web/data.csv'
    # Import the necessary modules
    import matplotlib.pyplot as plt
    import pandas as pd
    df=pd.read_csv(filename)
    index = df.index
    no_of_students = len(index)
    total_feedbacks = len(index) * 6

    df1 = df.groupby('teachingscore').count()[['teaching']]
    teaching_negative_count = df1['teaching'][-1]
    teaching_neutral_count = df1['teaching'][0]
    teaching_positive_count = df1['teaching'][1]

    df1 = df.groupby('coursecontentscore').count()[['coursecontent']]
    coursecontent_negative_count = df1['coursecontent'][-1]
    coursecontent_neutral_count = df1['coursecontent'][0]
    coursecontent_positive_count = df1['coursecontent'][1]

    df1 = df.groupby('examinationscore').count()[['examination']]
    examination_negative_count = df1['examination'][-1]
    examination_neutral_count = df1['examination'][0]
    examination_positive_count = df1['examination'][1]

    df1 = df.groupby('labworkscore').count()[['labwork']]
    labwork_negative_count = df1['labwork'][-1]
    labwork_neutral_count = df1['labwork'][0]
    labwork_positive_count = df1['labwork'][1]

    df1 = df.groupby('libraryfacilitiesscore').count()[['libraryfacilities']]
    libraryfacilities_negative_count = df1['libraryfacilities'][-1]
    libraryfacilities_neutral_count = df1['libraryfacilities'][0]
    libraryfacilities_positive_count = df1['libraryfacilities'][1]

    df1 = df.groupby('extracurricularscore').count()[['extracurricular']]
    extracurricular_negative_count = df1['extracurricular'][-1]
    extracurricular_neutral_count = df1['extracurricular'][0]
    extracurricular_positive_count = df1['extracurricular'][1]

    total_positive_feedbacks = teaching_positive_count + coursecontent_positive_count + examination_positive_count + labwork_positive_count + libraryfacilities_positive_count + extracurricular_positive_count
    total_neutral_feedbacks = teaching_neutral_count + coursecontent_neutral_count + examination_neutral_count + labwork_neutral_count + libraryfacilities_neutral_count + extracurricular_neutral_count
    total_negative_feedbacks = teaching_negative_count + coursecontent_negative_count + examination_negative_count + labwork_negative_count + libraryfacilities_negative_count + extracurricular_negative_count

    li = [teaching_positive_count, teaching_negative_count, teaching_neutral_count,
          coursecontent_positive_count, coursecontent_negative_count, coursecontent_neutral_count,
          examination_positive_count, examination_negative_count, examination_neutral_count,
          labwork_positive_count, labwork_negative_count, labwork_neutral_count,
          libraryfacilities_positive_count, libraryfacilities_negative_count, libraryfacilities_neutral_count,
          extracurricular_positive_count, extracurricular_negative_count, extracurricular_neutral_count]

    x = ["positive", "Neutral", "Negative"]
    y = [total_positive_feedbacks,total_neutral_feedbacks,total_negative_feedbacks]

    # making the bar chart on the data
    plt.bar(x, y,color="red")

        # calling the function to add value labels
    for i in range(len(x)):
        plt.text(i, y[i], y[i])

        # giving title to the plot
    plt.title("feedback analysis")
    # giving X and Y labels
    plt.ylabel("Number of feedbacks")

        # visualizing the plot


    img1=plt.show()
    response=img1
    return(img1)


def pie(request):
    filename = 'vv_web/data.csv'
    # Import the necessary modules
    import matplotlib.pyplot as plt
    import pandas as pd
    df = pd.read_csv(filename)
    index = df.index
    no_of_students = len(index)
    total_feedbacks = len(index) * 6

    df1 = df.groupby('teachingscore').count()[['teaching']]
    teaching_negative_count = df1['teaching'][-1]
    teaching_neutral_count = df1['teaching'][0]
    teaching_positive_count = df1['teaching'][1]

    df1 = df.groupby('coursecontentscore').count()[['coursecontent']]
    coursecontent_negative_count = df1['coursecontent'][-1]
    coursecontent_neutral_count = df1['coursecontent'][0]
    coursecontent_positive_count = df1['coursecontent'][1]

    df1 = df.groupby('examinationscore').count()[['examination']]
    examination_negative_count = df1['examination'][-1]
    examination_neutral_count = df1['examination'][0]
    examination_positive_count = df1['examination'][1]

    df1 = df.groupby('labworkscore').count()[['labwork']]
    labwork_negative_count = df1['labwork'][-1]
    labwork_neutral_count = df1['labwork'][0]
    labwork_positive_count = df1['labwork'][1]

    df1 = df.groupby('libraryfacilitiesscore').count()[['libraryfacilities']]
    libraryfacilities_negative_count = df1['libraryfacilities'][-1]
    libraryfacilities_neutral_count = df1['libraryfacilities'][0]
    libraryfacilities_positive_count = df1['libraryfacilities'][1]

    df1 = df.groupby('extracurricularscore').count()[['extracurricular']]
    extracurricular_negative_count = df1['extracurricular'][-1]
    extracurricular_neutral_count = df1['extracurricular'][0]
    extracurricular_positive_count = df1['extracurricular'][1]

    total_positive_feedbacks = teaching_positive_count + coursecontent_positive_count + examination_positive_count + labwork_positive_count + libraryfacilities_positive_count + extracurricular_positive_count
    total_neutral_feedbacks = teaching_neutral_count + coursecontent_neutral_count + examination_neutral_count + labwork_neutral_count + libraryfacilities_neutral_count + extracurricular_neutral_count
    total_negative_feedbacks = teaching_negative_count + coursecontent_negative_count + examination_negative_count + labwork_negative_count + libraryfacilities_negative_count + extracurricular_negative_count

    li = [teaching_positive_count, teaching_negative_count, teaching_neutral_count,
          coursecontent_positive_count, coursecontent_negative_count, coursecontent_neutral_count,
          examination_positive_count, examination_negative_count, examination_neutral_count,
          labwork_positive_count, labwork_negative_count, labwork_neutral_count,
          libraryfacilities_positive_count, libraryfacilities_negative_count, libraryfacilities_neutral_count,
          extracurricular_positive_count, extracurricular_negative_count, extracurricular_neutral_count]

    fig = plt.figure(figsize=(10, 5))
    # Creating dataset
    x = ['positive','negative','neutral']

    y = [total_positive_feedbacks,total_negative_feedbacks,total_neutral_feedbacks]

    # Creating plot
    plt.pie(y, labels=x)

    # show plot
    retult=plt.show()

    return result



